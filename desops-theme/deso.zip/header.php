<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Design Ops Israel</title>
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css">




    <?php wp_head();?>



</head>
<body
    onresize="document.getElementsByTagName('iframe')[0].style.height=document.getElementsByTagName('iframe')[0].contentWindow.document.getElementsByTagName('body')[0].offsetHeight+'px';">

<div id="wrapper" class="article">
    <div class="section c-flex-center logo">
        <a href="https://desops.co.il" target="_self"><img src="https://desops.co.il/images/ops-logo.svg" /></a>
    </div>