
<?php wp_footer();?>

</div>
<div id="wrapper">
        <iframe src="https://desops.co.il/footer.html" frameborder="0" class="full-width footer-frame"
            onload="this.style.height=this.contentWindow.document.getElementsByTagName('body')[0].offsetHeight+'px';"></iframe>
        <footer></footer>
    </div>
</body>
</html>